#!/usr/bin/env python3
"""
Facebook Competitor Post Scraper
Uses Playwright for browser automation to collect public posts
"""

import json
import asyncio
import sqlite3
from datetime import datetime
from pathlib import Path
from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeout

# Project paths
BASE_DIR = Path(__file__).parent.parent
DATA_DIR = BASE_DIR / "data"
CONFIG_DIR = BASE_DIR / "config"
LOGS_DIR = BASE_DIR / "logs"

# Ensure directories exist
DATA_DIR.mkdir(exist_ok=True)
LOGS_DIR.mkdir(exist_ok=True)

class FacebookScraper:
    def __init__(self):
        self.config = self._load_config()
        self.db_path = DATA_DIR / "competitor_posts.db"
        self._init_database()
    
    def _load_config(self):
        """Load competitor configuration"""
        config_path = CONFIG_DIR / "competitors.json"
        with open(config_path, 'r') as f:
            return json.load(f)
    
    def _init_database(self):
        """Initialize SQLite database for storing posts"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS posts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                competitor_name TEXT,
                post_text TEXT,
                post_date TEXT,
                engagement_likes INTEGER,
                engagement_comments INTEGER,
                engagement_shares INTEGER,
                post_url TEXT,
                scraped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(competitor_name, post_url)
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS scraping_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                competitor_name TEXT,
                status TEXT,
                posts_found INTEGER,
                error_message TEXT,
                scraped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        conn.commit()
        conn.close()
        print(f"✓ Database initialized at {self.db_path}")
    
    async def scrape_competitor(self, competitor):
        """Scrape posts from a single competitor's Facebook page"""
        name = competitor['name']
        url = competitor['facebook_url']
        settings = self.config['scraping_settings']
        
        print(f"\n🎯 Scraping {name}...")
        print(f"   URL: {url}")
        
        posts_data = []
        
        async with async_playwright() as p:
            # Launch browser
            browser = await p.chromium.launch(
                headless=settings['headless']
            )
            
            context = await browser.new_context(
                viewport={'width': 1920, 'height': 1080},
                user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            )
            
            page = await context.new_page()
            
            try:
                # Navigate to Facebook page
                await page.goto(url, wait_until='networkidle', timeout=30000)
                await asyncio.sleep(3)  # Wait for dynamic content
                
                # Handle "See more" buttons and scroll
                for scroll_num in range(3):  # Scroll 3 times to load more posts
                    await page.evaluate('window.scrollBy(0, window.innerHeight)')
                    await asyncio.sleep(settings['scroll_delay_seconds'])
                    
                    # Click "See more" if available
                    try:
                        see_more_buttons = await page.query_selector_all('div[role="button"]:has-text("See more")')
                        for button in see_more_buttons[:5]:  # Expand first 5 posts
                            await button.click()
                            await asyncio.sleep(0.5)
                    except Exception as e:
                        pass  # Continue if no "See more" buttons
                
                # Extract post content
                # Note: Facebook's DOM changes frequently, these selectors may need updates
                post_elements = await page.query_selector_all('div[data-ad-preview="message"]')
                
                print(f"   Found {len(post_elements)} potential post elements")
                
                for idx, post_elem in enumerate(post_elements[:settings['max_posts_per_page']]):
                    try:
                        # Extract text content
                        text_content = await post_elem.inner_text()
                        
                        # Try to find engagement metrics (likes, comments, shares)
                        # This is approximate as Facebook hides exact counts
                        parent = await post_elem.evaluate_handle('el => el.closest("div[role=\'article\']")')
                        
                        post_data = {
                            'competitor_name': name,
                            'post_text': text_content.strip(),
                            'post_date': datetime.now().isoformat(),  # Approximate
                            'engagement_likes': 0,  # Would need to parse if visible
                            'engagement_comments': 0,
                            'engagement_shares': 0,
                            'post_url': url  # Link to page, not individual post
                        }
                        
                        posts_data.append(post_data)
                        
                    except Exception as e:
                        print(f"   ⚠ Error extracting post {idx}: {str(e)}")
                        continue
                
                print(f"   ✓ Extracted {len(posts_data)} posts")
                
            except PlaywrightTimeout:
                error_msg = f"Timeout loading {url}"
                print(f"   ✗ {error_msg}")
                self._log_scraping(name, 'error', 0, error_msg)
                
                if settings['screenshot_on_error']:
                    screenshot_path = LOGS_DIR / f"{name.replace(' ', '_')}_error.png"
                    await page.screenshot(path=str(screenshot_path))
                    print(f"   Screenshot saved to {screenshot_path}")
                
            except Exception as e:
                error_msg = f"Error: {str(e)}"
                print(f"   ✗ {error_msg}")
                self._log_scraping(name, 'error', 0, error_msg)
                
            finally:
                await browser.close()
        
        # Save to database
        if posts_data:
            self._save_posts(posts_data)
            self._log_scraping(name, 'success', len(posts_data), None)
        
        return posts_data
    
    def _save_posts(self, posts_data):
        """Save scraped posts to database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        for post in posts_data:
            try:
                cursor.execute('''
                    INSERT OR IGNORE INTO posts 
                    (competitor_name, post_text, post_date, engagement_likes, 
                     engagement_comments, engagement_shares, post_url)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (
                    post['competitor_name'],
                    post['post_text'],
                    post['post_date'],
                    post['engagement_likes'],
                    post['engagement_comments'],
                    post['engagement_shares'],
                    post['post_url']
                ))
            except Exception as e:
                print(f"   ⚠ Error saving post: {e}")
        
        conn.commit()
        conn.close()
    
    def _log_scraping(self, competitor_name, status, posts_found, error_message):
        """Log scraping attempt"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO scraping_log (competitor_name, status, posts_found, error_message)
            VALUES (?, ?, ?, ?)
        ''', (competitor_name, status, posts_found, error_message))
        
        conn.commit()
        conn.close()
    
    async def scrape_all(self):
        """Scrape all enabled competitors"""
        print("🚀 Starting Facebook Competitor Scraper")
        print("=" * 60)
        
        enabled_competitors = [
            c for c in self.config['competitors'] if c.get('enabled', True)
        ]
        
        print(f"Found {len(enabled_competitors)} enabled competitors\n")
        
        all_posts = []
        for competitor in enabled_competitors:
            posts = await self.scrape_competitor(competitor)
            all_posts.extend(posts)
        
        print("\n" + "=" * 60)
        print(f"✅ Scraping complete! Total posts collected: {len(all_posts)}")
        print(f"📊 Database: {self.db_path}")
        
        return all_posts
    
    def get_recent_posts(self, limit=50):
        """Retrieve recent posts from database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT competitor_name, post_text, post_date, scraped_at
            FROM posts
            ORDER BY scraped_at DESC
            LIMIT ?
        ''', (limit,))
        
        posts = cursor.fetchall()
        conn.close()
        
        return posts

async def main():
    """Main execution function"""
    scraper = FacebookScraper()
    await scraper.scrape_all()

if __name__ == "__main__":
    asyncio.run(main())
