# 🚀 QUICK START GUIDE

## Installation (5 minutes)

1. **Install dependencies:**
   ```bash
   cd facebook-competitor-scraper
   pip install -r requirements.txt
   playwright install chromium
   ```

2. **Set your API key:**
   ```bash
   # Linux/Mac
   export ANTHROPIC_API_KEY="sk-ant-your-key-here"
   
   # Windows PowerShell
   $env:ANTHROPIC_API_KEY="sk-ant-your-key-here"
   ```

3. **Run setup wizard:**
   ```bash
   python setup.py
   ```
   - Enter competitor names and Facebook URLs
   - Setup wizard will guide you through config

## Daily Usage

### Scrape Posts
```bash
python scripts/scraper.py
```

### Analyze with AI
```bash
# Analyze all posts
python scripts/analyzer.py analyze

# Analyze specific competitor
python scripts/analyzer.py analyze "Competitor Name"

# Compare competitors
python scripts/analyzer.py compare
```

### Check Status
```bash
python setup.py status
```

## VS Code Integration

1. **Open workspace:**
   - File → Open Workspace from File
   - Select `facebook-scraper.code-workspace`

2. **Run with debugger:**
   - Press F5
   - Choose configuration:
     - "Run Scraper"
     - "Analyze Posts"
     - "Compare Competitors"

3. **Run tasks:**
   - Terminal → Run Task
   - Select task to run

## File Locations

- **Config:** `config/competitors.json` - Edit your competitors here
- **Database:** `data/competitor_posts.db` - All scraped posts
- **Analysis:** `data/analysis_*.txt` - AI-generated insights
- **Logs:** `logs/` - Error screenshots

## Troubleshooting

**No posts found?**
- Set `"headless": false` in config to see browser
- Facebook URL might be wrong
- Facebook may have changed HTML structure

**API key error?**
- Check: `echo $ANTHROPIC_API_KEY`
- Set again: `export ANTHROPIC_API_KEY="your-key"`

**Playwright error?**
- Run: `playwright install chromium`

## Next Steps

1. **Automate with cron/Task Scheduler** (see README)
2. **Integrate with MCP servers** for Claude Desktop
3. **Add more competitors** to `config/competitors.json`
4. **Customize analysis prompts** in `analyzer.py`

---

**Need help?** Check the full README.md for detailed documentation.
