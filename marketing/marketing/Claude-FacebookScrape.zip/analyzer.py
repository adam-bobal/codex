#!/usr/bin/env python3
"""
Competitor Post Analyzer using Anthropic API
Analyzes scraped posts for trends, themes, and insights
"""

import json
import sqlite3
import os
from pathlib import Path
from anthropic import Anthropic

BASE_DIR = Path(__file__).parent.parent
DATA_DIR = BASE_DIR / "data"

class PostAnalyzer:
    def __init__(self, api_key=None):
        """Initialize with Anthropic API key"""
        self.api_key = api_key or os.environ.get('ANTHROPIC_API_KEY')
        if not self.api_key:
            raise ValueError("ANTHROPIC_API_KEY not found in environment")
        
        self.client = Anthropic(api_key=self.api_key)
        self.db_path = DATA_DIR / "competitor_posts.db"
    
    def get_posts_by_competitor(self, competitor_name=None, limit=50):
        """Fetch posts from database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        if competitor_name:
            cursor.execute('''
                SELECT competitor_name, post_text, post_date
                FROM posts
                WHERE competitor_name = ?
                ORDER BY scraped_at DESC
                LIMIT ?
            ''', (competitor_name, limit))
        else:
            cursor.execute('''
                SELECT competitor_name, post_text, post_date
                FROM posts
                ORDER BY scraped_at DESC
                LIMIT ?
            ''', (limit,))
        
        posts = cursor.fetchall()
        conn.close()
        
        return posts
    
    def analyze_trends(self, competitor_name=None):
        """Use Claude to analyze posting trends and themes"""
        posts = self.get_posts_by_competitor(competitor_name, limit=50)
        
        if not posts:
            print("No posts found to analyze")
            return None
        
        # Prepare posts for analysis
        posts_text = "\n\n---\n\n".join([
            f"Competitor: {p[0]}\nDate: {p[2]}\nPost: {p[1]}"
            for p in posts
        ])
        
        # Create analysis prompt
        prompt = f"""Analyze these competitor Facebook posts and provide insights:

{posts_text}

Please provide:
1. **Key Themes**: What topics are they posting about?
2. **Posting Patterns**: How frequently? What type of content?
3. **Engagement Strategy**: What seems to drive engagement?
4. **Content Gaps**: What aren't they covering that we could?
5. **Actionable Insights**: Specific recommendations for our strategy

Format as a structured analysis."""

        print("🤖 Analyzing posts with Claude...")
        
        # Call Anthropic API
        message = self.client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=2000,
            messages=[
                {"role": "user", "content": prompt}
            ]
        )
        
        analysis = message.content[0].text
        
        # Save analysis to file
        timestamp = Path(DATA_DIR / f"analysis_{competitor_name or 'all'}_{Path().cwd()}.json")
        analysis_file = DATA_DIR / f"analysis_{competitor_name or 'all'}.txt"
        
        with open(analysis_file, 'w') as f:
            f.write(analysis)
        
        print(f"✅ Analysis saved to {analysis_file}")
        
        return analysis
    
    def compare_competitors(self):
        """Compare multiple competitors"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('SELECT DISTINCT competitor_name FROM posts')
        competitors = [row[0] for row in cursor.fetchall()]
        conn.close()
        
        if len(competitors) < 2:
            print("Need at least 2 competitors to compare")
            return None
        
        # Get posts for each competitor
        competitor_summaries = []
        for comp in competitors:
            posts = self.get_posts_by_competitor(comp, limit=10)
            post_texts = [p[1] for p in posts]
            competitor_summaries.append({
                'name': comp,
                'post_count': len(posts),
                'sample_posts': post_texts[:5]
            })
        
        # Create comparison prompt
        comparison_data = json.dumps(competitor_summaries, indent=2)
        
        prompt = f"""Compare these competitors based on their Facebook posts:

{comparison_data}

Provide:
1. **Competitive Positioning**: How does each differentiate?
2. **Content Strategy Comparison**: What's unique about each?
3. **Strengths & Weaknesses**: For each competitor
4. **Market Opportunities**: Gaps we can exploit
5. **Recommended Actions**: Specific tactics to stand out

Format as a strategic comparison."""

        print("🤖 Running competitive comparison analysis...")
        
        message = self.client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=2500,
            messages=[
                {"role": "user", "content": prompt}
            ]
        )
        
        comparison = message.content[0].text
        
        # Save comparison
        comparison_file = DATA_DIR / "competitor_comparison.txt"
        with open(comparison_file, 'w') as f:
            f.write(comparison)
        
        print(f"✅ Comparison saved to {comparison_file}")
        
        return comparison

def main():
    """Main execution"""
    import sys
    
    analyzer = PostAnalyzer()
    
    if len(sys.argv) > 1:
        command = sys.argv[1]
        
        if command == "analyze":
            competitor = sys.argv[2] if len(sys.argv) > 2 else None
            analysis = analyzer.analyze_trends(competitor)
            print("\n" + "="*60)
            print(analysis)
        
        elif command == "compare":
            comparison = analyzer.compare_competitors()
            print("\n" + "="*60)
            print(comparison)
        
        else:
            print("Usage: python analyzer.py [analyze|compare] [competitor_name]")
    
    else:
        # Default: analyze all posts
        analysis = analyzer.analyze_trends()
        print("\n" + "="*60)
        print(analysis)

if __name__ == "__main__":
    main()
