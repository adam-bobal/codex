#!/usr/bin/env python3
"""
Quick Start Setup Script
Helps you configure and test the Facebook scraper
"""

import json
import os
import sys
from pathlib import Path

def setup_wizard():
    print("🍕 Facebook Competitor Scraper - Setup Wizard")
    print("=" * 60)
    
    config_path = Path("config/competitors.json")
    
    # Check if config exists
    if config_path.exists():
        print("\n✓ Config file exists at:", config_path)
        response = input("Do you want to add competitors? (y/n): ")
        if response.lower() != 'y':
            return
        
        with open(config_path, 'r') as f:
            config = json.load(f)
    else:
        config = {
            "competitors": [],
            "scraping_settings": {
                "max_posts_per_page": 20,
                "scroll_delay_seconds": 2,
                "headless": True,
                "screenshot_on_error": True
            }
        }
    
    # Add competitors
    print("\n📝 Add Competitor Information")
    print("-" * 60)
    
    while True:
        print("\nEnter competitor details (or press Enter to finish):")
        
        name = input("  Competitor name: ").strip()
        if not name:
            break
        
        url = input("  Facebook URL: ").strip()
        if not url.startswith("https://"):
            url = "https://www.facebook.com/" + url
        
        tags_input = input("  Tags (comma-separated): ").strip()
        tags = [t.strip() for t in tags_input.split(",")] if tags_input else []
        
        competitor = {
            "name": name,
            "facebook_url": url,
            "enabled": True,
            "tags": tags
        }
        
        config['competitors'].append(competitor)
        print(f"  ✓ Added {name}")
    
    # Save config
    config_path.parent.mkdir(exist_ok=True)
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=2)
    
    print(f"\n✅ Configuration saved to {config_path}")
    print(f"   Total competitors: {len(config['competitors'])}")
    
    # Check API key
    print("\n🔑 Anthropic API Key")
    print("-" * 60)
    
    api_key = os.environ.get('ANTHROPIC_API_KEY')
    if api_key:
        print(f"✓ API key found: {api_key[:10]}...")
    else:
        print("⚠ No API key found in environment")
        print("\nTo set your API key:")
        print("  export ANTHROPIC_API_KEY='your-key-here'")
        print("  (or add to your .bashrc / .zshrc)")
    
    # Test run option
    print("\n🧪 Ready to Test?")
    print("-" * 60)
    response = input("Run a test scrape now? (y/n): ")
    
    if response.lower() == 'y':
        print("\n🚀 Starting test scrape...")
        os.system("python scripts/scraper.py")
    else:
        print("\nTo scrape later, run:")
        print("  python scripts/scraper.py")
        print("\nTo analyze posts, run:")
        print("  python scripts/analyzer.py analyze")

def show_status():
    """Show current status of scraper"""
    print("📊 Facebook Scraper Status")
    print("=" * 60)
    
    # Check config
    config_path = Path("config/competitors.json")
    if config_path.exists():
        with open(config_path, 'r') as f:
            config = json.load(f)
        
        competitors = config.get('competitors', [])
        enabled = [c for c in competitors if c.get('enabled', True)]
        
        print(f"\n✓ Config file: {config_path}")
        print(f"  Total competitors: {len(competitors)}")
        print(f"  Enabled: {len(enabled)}")
        
        if enabled:
            print("\n  Enabled competitors:")
            for c in enabled:
                print(f"    - {c['name']}")
    else:
        print("\n✗ No config file found")
        print("  Run: python setup.py to create one")
    
    # Check database
    db_path = Path("data/competitor_posts.db")
    if db_path.exists():
        import sqlite3
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM posts")
        post_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(DISTINCT competitor_name) FROM posts")
        competitor_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT MAX(scraped_at) FROM posts")
        last_scrape = cursor.fetchone()[0]
        
        conn.close()
        
        print(f"\n✓ Database: {db_path}")
        print(f"  Total posts: {post_count}")
        print(f"  Competitors scraped: {competitor_count}")
        print(f"  Last scrape: {last_scrape}")
    else:
        print(f"\n✗ No database found at {db_path}")
        print("  Database will be created on first scrape")
    
    # Check API key
    api_key = os.environ.get('ANTHROPIC_API_KEY')
    if api_key:
        print(f"\n✓ Anthropic API key configured")
    else:
        print(f"\n✗ No Anthropic API key found")
        print("  Set with: export ANTHROPIC_API_KEY='your-key'")

def main():
    if len(sys.argv) > 1:
        command = sys.argv[1]
        if command == "status":
            show_status()
        else:
            print("Usage: python setup.py [status]")
            print("  (no args): Run setup wizard")
            print("  status: Show current status")
    else:
        setup_wizard()

if __name__ == "__main__":
    main()
