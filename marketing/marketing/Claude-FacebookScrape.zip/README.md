# Facebook Competitor Post Scraper

**Zero-cost automation for collecting and analyzing competitor Facebook posts**

## 🎯 Features

- ✅ Scrapes public Facebook posts from competitor pages
- ✅ Stores posts in SQLite database
- ✅ AI-powered analysis using Anthropic API
- ✅ Tracks scraping history and logs
- ✅ Modular design for easy customization
- ✅ No external SaaS platforms required

## 📁 Project Structure

```
facebook-competitor-scraper/
├── config/
│   └── competitors.json      # Configure competitors here
├── data/
│   └── competitor_posts.db   # SQLite database (auto-created)
├── logs/                     # Error screenshots
├── scripts/
│   ├── scraper.py           # Main scraping script
│   └── analyzer.py          # AI analysis script
└── requirements.txt         # Python dependencies
```

## 🚀 Setup Instructions

### 1. Install Python Dependencies

```bash
cd facebook-competitor-scraper
pip install -r requirements.txt
playwright install chromium
```

### 2. Configure Competitors

Edit `config/competitors.json`:

```json
{
  "competitors": [
    {
      "name": "Your Competitor Name",
      "facebook_url": "https://www.facebook.com/competitorpage",
      "enabled": true,
      "tags": ["direct-competitor"]
    }
  ]
}
```

### 3. Set Anthropic API Key

```bash
# Linux/Mac
export ANTHROPIC_API_KEY="your-api-key-here"

# Windows PowerShell
$env:ANTHROPIC_API_KEY="your-api-key-here"

# Or add to your .env file
```

## 🎮 Usage

### Scrape Competitor Posts

```bash
python scripts/scraper.py
```

This will:
- Visit each enabled competitor's Facebook page
- Scroll and extract posts
- Save to SQLite database
- Log all activity

### Analyze Posts with AI

```bash
# Analyze all posts
python scripts/analyzer.py analyze

# Analyze specific competitor
python scripts/analyzer.py analyze "Competitor Name"

# Compare all competitors
python scripts/analyzer.py compare
```

### View Database Contents

```bash
sqlite3 data/competitor_posts.db

# SQL examples:
SELECT * FROM posts LIMIT 10;
SELECT competitor_name, COUNT(*) FROM posts GROUP BY competitor_name;
SELECT * FROM scraping_log ORDER BY scraped_at DESC;
```

## 🔧 Configuration Options

In `config/competitors.json`:

```json
{
  "scraping_settings": {
    "max_posts_per_page": 20,       // How many posts to collect
    "scroll_delay_seconds": 2,       // Wait time between scrolls
    "headless": true,                // Run browser in background
    "screenshot_on_error": true      // Save screenshots on errors
  }
}
```

## 📊 Database Schema

### `posts` table
- `id`: Auto-increment primary key
- `competitor_name`: Name from config
- `post_text`: Extracted post content
- `post_date`: Post date (approximate)
- `engagement_*`: Likes, comments, shares (if available)
- `post_url`: Link to Facebook page
- `scraped_at`: When data was collected

### `scraping_log` table
- Tracks each scraping attempt
- Records success/failure
- Stores error messages

## 🤖 AI Analysis Features

The analyzer uses Claude to:
1. **Identify key themes** in competitor posts
2. **Detect posting patterns** and frequency
3. **Analyze engagement strategies**
4. **Find content gaps** you can exploit
5. **Generate actionable insights**
6. **Compare multiple competitors** side-by-side

## ⚠️ Important Notes

### Facebook Scraping Limitations
- **Only works on PUBLIC pages** (no login required)
- Facebook frequently changes their HTML structure
- Selectors may need updates over time
- Rate limiting: Don't scrape too aggressively
- Engagement metrics may not be visible without login

### Legal & Ethical Considerations
- Only scrape public information
- Respect Facebook's Terms of Service
- Use for competitive research, not data theft
- Consider adding delays between requests
- Don't overwhelm their servers

## 🔄 Automation Options

### Schedule with Cron (Linux/Mac)
```bash
# Run daily at 9 AM
0 9 * * * cd /path/to/scraper && python scripts/scraper.py
```

### Schedule with Task Scheduler (Windows)
1. Open Task Scheduler
2. Create Basic Task
3. Trigger: Daily at 9 AM
4. Action: Start a program
5. Program: `python`
6. Arguments: `scripts/scraper.py`
7. Start in: `C:\path\to\scraper`

## 🛠️ Troubleshooting

### Playwright Not Finding Browser
```bash
playwright install chromium
```

### No Posts Found
- Check if competitor URL is correct
- Try setting `headless: false` to see browser
- Facebook may have changed their HTML structure
- Page might require login (not supported)

### API Key Error
```bash
echo $ANTHROPIC_API_KEY  # Should show your key
export ANTHROPIC_API_KEY="sk-ant-..."
```

### Database Locked
- Close any other programs accessing the database
- Only one script should write at a time

## 🔮 Future Enhancements

- [ ] Add image scraping
- [ ] Extract exact post dates
- [ ] Capture engagement metrics
- [ ] Sentiment analysis
- [ ] Keyword tracking
- [ ] Email reports
- [ ] MCP server integration
- [ ] Dashboard visualization

## 📝 Integration with MCP

This scraper can be integrated with Claude Desktop via MCP:

1. Create MCP filesystem server pointing to `/data` directory
2. Use MCP memory server to track scraping schedules
3. Query database directly from Claude Desktop
4. Trigger analysis via natural language

Example MCP workflow:
```
User: "Show me what competitors posted this week"
Claude: [Uses MCP to query SQLite] → Returns summary
User: "Analyze the themes"
Claude: [Calls analyzer.py via MCP] → Returns insights
```

## 🤝 Contributing

Feel free to:
- Update Facebook selectors when they break
- Add new analysis features
- Improve error handling
- Add visualization tools

## 📄 License

Open source - use freely for your business automation needs.

---

**Built with:** Python, Playwright, SQLite, Anthropic API
**Philosophy:** Zero-cost, open-source, AI-powered business intelligence
